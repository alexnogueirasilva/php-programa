<html>
<head>
   <title>Multiple Upload Ajax</title>
</head>
<body>
 
   <form id="formImage" method="POST" enctype="multipart/form-data" >
      <input type="file" name="fileUpload">
      <input type="submit" value="Enviar" onclick="saveImages()">
   </form>

  

   <script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
   <script src="//malsup.github.io/jquery.form.js"></script>

   <script>
  
     
      $(document).ready(function(){
         

         
      });

   </script>
</body>
</html>