    <footer class="footer text-center"> 2019 &copy; SD - Sistemas de Ocorrência  </footer>
        
    </div>
    <!-- /#wrapper -->
    <!-- jQuery -->

    <script src="../assets/bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="../assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- Menu Plugin JavaScript -->
    <script src="../assets/bower_components/metisMenu/dist/metisMenu.min.js"></script>
    <!--Nice scroll JavaScript -->
    <script src="js/jquery.nicescroll.js"></script>
    <!-- ============================================================== -->
    <!-- This page plugins -->
    <!-- ============================================================== -->
    <!-- chartist chart -->
    <script src="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.4.0/js/bootstrap4-toggle.min.js"></script>
    <script src="../assets/bower_components/bootstrap-toggle/js/bootstrap-toggle.min.js"></script>
    <script src="../assets/bower_components/chartist-js/dist/chartist.min.js"></script>
    <script src="../assets/bower_components/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.min.js"></script>
    <script src="../assets/bower_components/jquery-sparkline/jquery.sparkline.min.js"></script>
    <script src="../assets/bower_components/jquery-sparkline/jquery.charts-sparkline.js"></script>
    <script src="../assets/bower_components/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
    <script src="../assets/bower_components/vectormap/jquery-jvectormap-world-mill-en.js"></script>
    <!--Wave Effects -->
   
    
    <script src="js/dashboard1.js"></script>

    <script src="../assets/bower_components/datatables/jquery.dataTables.min.js"></script>
            <script>
            $(document).ready(function() {   
                //$('#tabela').DataTable();
                $("#tabela").DataTable({
               //TRADUÇÃO DATATABLE
                "oLanguage": {
                    "sProcessing":   "Processando...",
                    "sLengthMenu":   "Mostrar _MENU_ registros",
                    "sZeroRecords":  "Não foram encontrados resultados",
                    "sInfo":         "",
                    "sInfoEmpty":    "",
                    "sInfoFiltered": "",
                    "sInfoPostFix":  "",
                    "sSearch":       "Buscar:",
                    "sUrl":          "",
                    "oPaginate": {
                        "sFirst":    "Primeiro",
                        "sPrevious": "Anterior",
                        "sNext":     "Seguinte",
                        "sLast":     "Último"
                    }
                }
            });            
            });
            </script>
             <!--Wave Effects -->
    <script src="js/waves.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/myadmin.js"></script>
</body>

</html>
