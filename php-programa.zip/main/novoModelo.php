<?php
  require_once "cabecalho.php";

?>


<div data-toggle="toggle">

<!-- iOS Style: Rounded -->
<style>
  .toggle.ios, .toggle-on.ios, .toggle-off.ios { border-radius: 60rem; }
  .toggle.ios .toggle-handle { border-radius: 60rem; }
</style>
<input type="checkbox" checked data-toggle="toggle" data-style="ios">
<!-- Android Style: No radius -->

</div>
