<?php

/*//funcional
define('DB_HOST', "sql179.main-hosting.eu.");
define('DB_NAME', "u325780549_fab");
define('DB_USER', "u325780549_fab");
define('DB_PASS', "Bruna2012");
//mysql_query("SET NAMES 'utf8'");
*/

//teste
define('DB_HOST', "sql179.main-hosting.eu.");
define('DB_NAME', "u325780549_fab");
define('DB_USER', "u325780549_fab");
define('DB_PASS', "Bruna2012");
//mysql_query("SET NAMES 'utf8'");

?>